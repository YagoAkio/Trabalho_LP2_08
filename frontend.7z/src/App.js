import Pagina from "./templates/Pagina";

function App() {
  return (
    <div className="App">
      <Pagina>
          <p>Esse é um exemplo de uma página do sistema.</p>
      </Pagina>
    </div>
  );
}

export default App;
